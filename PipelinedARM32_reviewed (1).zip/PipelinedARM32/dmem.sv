module dmem #(
    parameter int WIDTH = 32,
    parameter int DEPTH = 256
) (
    input  logic             clk,
    input  logic             we,
    input  logic [WIDTH-1:0] a,
    input  logic [WIDTH-1:0] wd,
    output logic [WIDTH-1:0] rd
);
    logic [WIDTH-1:0] RAM [0:DEPTH-1];
    integer i;

    initial begin
        for (i = 0; i < DEPTH; i = i + 1) begin
            RAM[i] = '0;
        end
    end
    
    // TODO: Shouldn't this be negative edge?
    always @(negedge clk) begin
        if (we) RAM[a[WIDTH-1:2]] <= wd;
    end

    assign rd = RAM[a[WIDTH-1:2]];
endmodule
